%% code to calibrate two cameras using real world and image points


% reading in images from front and side camera
front_im = im2double(imread('front_rot_im.jpg'));
side_im = im2double(imread('side_rot_im.jpg'));

% declaring real points and specifying which are used for each image
real_pts = [0, 0, 0.258; 
    0, 0.210, 0.258; 
    0, -0.210, 0.258; 
    -0.170, -0.210, 0.258;
    -0.340, -0.210, 0.258; 
    0, 0, 0.518;
    0, 0.210, 0.518; 
    0, -0.210, 0.518; 
    -0.170, -0.210, 0.518; 
    -0.340, -0.210, 0.518; 
    -0.052, 0.115, 0.549;
    -0.265, -0.125, 0.549; 
    -0.052, 0.115, 1.189; 
    -0.265, -0.125, 1.179; 
    -0.160, 0, 0.628; 
    -0.160, 0, 1.063; 
    -0.160, 0, 1.488];

% rotating points by 45 degrees around z axis to match structure
theta = pi/4;
rot = [cos(theta), -sin(theta), 0; sin(theta), cos(theta), 0; 0, 0, 1;];
real_pts = ( rot*(real_pts') )';

% shifting every element in real points by (0.042, 0.085)
for i = 1:size(real_pts,1)
    real_pts(i,1) = real_pts(i,1) + 0.042;
    real_pts(i,2) = real_pts(i,2) + 0.085;
end

% plotting 3d points
% figure;
% plot3(real_pts(:,1), real_pts(:,2), real_pts(:,3),'o')
% axis equal
% axis vis3d
% xlabel('X')
% ylabel('Y')
% zlabel('Z')
% grid on


f_index = [1, 3, 4, 6, 8, 9, 11, 12, 13, 14, 15, 16, 17]';
front_real_pts = zeros(size(f_index,1),3);
for i = 1:size(f_index,1)
    front_real_pts(i,1) = real_pts(f_index(i),1);
    front_real_pts(i,2) = real_pts(f_index(i),2);
    front_real_pts(i,3) = real_pts(f_index(i),3);
end    
     
s_index = [3, 4, 5, 8, 9, 10, 12, 14, 17]';
side_real_pts = zeros(size(s_index,1),3);
for i = 1:size(s_index,1)
    side_real_pts(i,1) = real_pts(s_index(i),1);
    side_real_pts(i,2) = real_pts(s_index(i),2);
    side_real_pts(i,3) = real_pts(s_index(i),3);
end    

% adding additional points
% order: low outlet, high outlet, white part of cord, line at painting,
% back corner
more_pts = [0.740,0.390,0.190; 0.258,0.390,1.000; -0.650,0.153,0; 
    -0.780,0.767,0; -1.072,0.370,0.093];

front_real_pts = [front_real_pts; more_pts];
side_real_pts = [side_real_pts; more_pts];

% Selecting image points for each
front_im_pts = selectImPts(front_im,size(front_real_pts,1));
side_im_pts = selectImPts(side_im,size(side_real_pts,1));

%%
% checking getKRT with given M, K, R, t vals
% M_test = [ -2.36, 1.06, -0.75, 1229.34; 0.29, 0.44, -2.34, 819.39; -6.567*10^(-4), -4.66*10^(-4), -6.14*10^(-4),1];
% [K_test, R_test, t_test] = getKRT(M_test)

front_M = estimateCameraProjectionMatrix( front_im_pts, front_real_pts);
[front_K, front_R, front_t] = getKRT(front_M);

% testing K, R, t
front_est_pts = getEstimatedPoints(front_K, front_R, front_t, front_real_pts);
[H_f,W_f] = size(front_im);
figure;
imshow(front_im);
axis on
xlim = ([0, W_f]);
ylim = ([0, H_f]);
hold on;
plot(front_im_pts(:,1),front_im_pts(:,2),'b.');
plot(front_est_pts(:,1), front_est_pts(:,2),'ro','MarkerSize',40);

function [im_pts] = selectImPts(image, numPts)
    % displaying image for ginput
    figure()
    imshow(image);
    hold on;
    
    % creating return variable and index
    im_pts = zeros(numPts,2);
    i = 1;
    while i <= numPts
        % get point
        [x,y] = ginput(1);
        % add point to return matrix
        im_pts(i,1) = x;
        im_pts(i,2) = y;
        plot(x,y,'r')
        % increase index
        i = i+1;
    end
    hold off;
end

function M = estimateCameraProjectionMatrix( im_pts, real_pts)
    % creating design matrix P
    P = zeros(2*size(real_pts,1), 12);
    % indexing
    i=1;
    for j = 1:2*size(real_pts,1)-1:2
        % odd rows
        P(j,1) = -1*real_pts(i,1);
        P(j,2) = -1*real_pts(i,2); 
        P(j,3) = -1*real_pts(i,3);
        P(j,4) = -1;
        P(j,5:8) = 0;
        P(j,9) = im_pts(i,1)*real_pts(i,1);
        P(j,10) = im_pts(i,1)*real_pts(i,2);
        P(j,11) = im_pts(i,1)*real_pts(i,3);
        P(j,12) = im_pts(i,1);
        % even rows
        P(j+1,1:4) = 0;
        P(j+1,5) = -1*real_pts(i,1);
        P(j+1,6) = -1*real_pts(i,2); 
        P(j+1,7) = -1*real_pts(i,3);
        P(j+1,8) = -1;
        P(j+1,8) = im_pts(i,2)*real_pts(i,1);
        P(j+1,10) = im_pts(i,2)*real_pts(i,2);
        P(j+1,11) = im_pts(i,2)*real_pts(i,3);
        P(j+1,12) = im_pts(i,2);
        % indexing i
        i = i + 1;
    end
    
    % doing svd
    [~,~,v] = svd(P,'econ');
    q = v(:,size(v,2));
    
    % rearranging q
    M = zeros(3,4);
    M(1,1) = q(1);
    M(1,2) = q(2);
    M(1,3) = q(3);
    M(1,4) = q(4);
    M(2,1) = q(5);
    M(2,2) = q(6);
    M(2,3) = q(7);
    M(2,4) = q(8);
    M(3,1) = q(9);
    M(3,2) = q(10);
    M(3,3) = q(11);
    M(3,4) = q(12);
end
        
function [K, R, t] = getKRT(M)
    % setting A, b and C
    A = M(:,[1:3]);
    b = M(:,4);
    C = A* (A');
    
    % solving for parameters
    lambda_sq = 1/C(3,3);
    lambda_pos = abs(sqrt(lambda_sq));
    lambda_neg  = -1*abs(sqrt(lambda_sq));
    x_c = C(1,3)/C(3,3);
    y_c = C(2,3)/C(3,3);
    f_y = abs( sqrt( (C(2,2)/C(3,3)) - (C(2,3)/C(3,3))^2 ) );
    alpha = ( (lambda_sq*C(1,2)) - (x_c*y_c) ) / f_y;
    f_x = abs( sqrt( lambda_sq*C(1,1) - alpha^2 - x_c^2) );
    
    % creating k, R and t
    K = [f_x, alpha, x_c; 0, f_y, y_c; 0, 0, 1]
    R_pos = (inv(K)*A)/sqrt(C(3,3))
    det_pos = det(R_pos)
    R_neg = -1*R_pos
    det_neg = det(R_neg)
    lambda = 0;
    if abs( det_pos - 1) < 0.05
        R = R_pos;
        lambda = lambda_pos;
    elseif abs( det_neg - 1) < 0.05
        R = R_neg;
        lambda = lambda_neg;
    elseif  abs( det_neg ) - abs( det_pos ) < 0.05
        % if the determinants are the same, use positive
        R = R_pos;
        lambda = lambda_pos;
    else
        fprintf("neither R matrix has a determinant of 1");
    end
    t = lambda*inv(K)*b;

end
        
function est_pts = getEstimatedPoints(K, R, t, real_pts)
    % adding a row of ones to the bottom of real pts
    real_pts = real_pts';
    ones_to_add = ones(1,size(real_pts,2));
    real_pts = [real_pts; ones_to_add];
    % transforming
    t_pts = K * [R,t] * real_pts;
    % normalizing
    t_pts(1,:) = t_pts(1,:)./t_pts(3,:);
    t_pts(2,:) = t_pts(2,:)./t_pts(3,:);
    % making estimated points matrix and returning
    est_pts = [t_pts(1,:); t_pts(2,:)]';
end


        
        
        
        
        
        
        
        
        
        
        
        
    
    
